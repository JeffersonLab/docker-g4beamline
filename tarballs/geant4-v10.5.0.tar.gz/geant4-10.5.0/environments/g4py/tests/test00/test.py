#!/usr/bin/python
# ==================================================================
# python script for Geant4Py test
#
#
# ==================================================================
import test00

print "importing created module...\n"

print test00.greet()

