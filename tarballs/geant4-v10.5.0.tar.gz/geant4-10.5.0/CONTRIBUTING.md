The Geant4 Collaboration:
http://cern.ch/geant4/collaboration/members
